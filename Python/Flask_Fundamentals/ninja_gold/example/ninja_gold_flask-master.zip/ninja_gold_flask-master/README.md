# ninja_gold_flask

Ninja Gold Game build using Python 2.7 and Flask 0.11.1!
