from __future__ import unicode_literals
from django.shortcuts import render, HttpResponse, redirect
from .models import *
import bcrypt
from django.contrib import messages
import datetime
# from django.contrib.auth.hashers import make_password, check_password
# from django.contrib.auth import authenticate
# from django.contrib.auth import views as auth_views


#INDEX WELCOME PAGE
def index(request):
    if "userid" in request.session:  
        return render(request,'beltapp/appointments.html')
    else:                           
        return render(request, 'beltapp/index.html') 

def createuser(request):
    errors = User.objects.validate(request.POST)
    if len(errors):
        for error in errors:
            messages.error(request, error)
        return redirect('/')
    else:
        hashmasterflash = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()) 
        newuser = User.objects.create(
            name=request.POST['name'],
            email=request.POST['email'],
            birth_date=request.POST['birth_date'],
            password=hashmasterflash,
            )
        request.session['userid'] = newuser.id
        request.session['name'] = newuser.name
        return render(request, 'beltapp/appointments.html')

def login(request):
    errors = User.objects.loginvalidate(request.POST)
    if len(errors) > 0:
        for error in errors:
            messages.error(request, error)
        return redirect('/')
    else:
        user = User.objects.filter(email=request.POST['email'])[0]
        request.session['userid'] = user.id
        request.session['name'] = user.name
        return render(request, 'beltapp/appointments.html')

def show(request, id):
    user = request.session['userid']
    userlist = user.objects.filter(id=id)
    if len(userlist) > 0:
        user = user[0]
        time = user.objects.filter(time=time)
        context = {
            "task": task,
            'time': time
        }
        print context
        return render(request, "show.html", context)
    else:
        return redirect("/")


def createappointment(request):
    errors = Appointment.objects.validate(request.POST)
    if len(errors):
        for error in errors:
            messages.error(request, error)
        return redirect('/appointments')
    else:
        Appointment.objects.create(
            date=request.POST['date'],
            time=request.POST['time'],
            task=request.POST['task']
        )
        return render(request, 'beltapp/edit.html')


def edit(request, id):
    appointment_list = appointments.objects.filter(id=id)
    if len(appointment_list) > 0:
        appointment = appointment_list[0]
        context = {
            "task": task,
            "status": status,
            "date": date,
            "time": time
        }
        return render(request, "edit.html", context)
    else:
        return render(request, 'appointments.html')

def update(request, id):
    appointment_list = appointments.objects.filter(id=id)
    if len(appointment_list) > 0:
        appointment = appointment_list[0]
        errors = appointments.objects.validate(request.POST)
        if len(errors) > 0:
            for error in errors:
                messages.error(request, error)
        else:
            appointment.name = request.POST['name']
            appointment.status = request.POST['status']
            appointment.date = request.POST['date']
            appointment.time = request.POST['time']
            appointment.save()
        return redirect("/edit"+id)
    else:
        return render(request, 'appointments.html')

def destroy(request, id):
    appointment = appointment.objects.get(id = id)
    appointment.delete()
    return redirect('/')

def delete(request, id):
    appointment = appointment.objects.get(id = id)
    return render(request, 'beltapp/delete.html', {"appointment" : appointment})

def logout(request, methods='POST'):
    request.session.clear() 
    return redirect('/')

# def success(request):
#     user = request.session['userid']
#     return render(request, 'beltapp/appointments.html')





