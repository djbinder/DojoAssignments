from django.conf.urls import url
from . import views      

urlpatterns = [
        url(r'^$', views.index),
        url(r'^createuser$', views.createuser),
        url(r'^login$', views.login),
        url(r'^createappointment$', views.createappointment),
        url(r'^appointments$', views.createappointment),
        url(r'^(?P<id>\d+)/edit$', views.edit),
        url(r'^(?P<id>\d+)/update$', views.update),
        url(r'^(?P<id>\d+)/destroy$', views.destroy),  
        url(r'^(?P<id>\d+)/delete$', views.delete),
        url(r'^logout$', views.logout),
]

# urlpatterns = [
#         url(r'^$', views.index),
#         url(r'^index$', views.index), 
#         url(r'^create$', views.create),
#         url(r'^login$', views.login),
#         url(r'^success$', views.success),
#         url(r'^logout$', views.logout),
# ]