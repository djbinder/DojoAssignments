$(document).ready(function(){
    $(".cubs_logo").click(function(){
        $(this).css("opacity","0"); 
    }); 
})